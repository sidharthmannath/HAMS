from django.shortcuts import *
from django.contrib.auth import authenticate
from django.shortcuts import redirect
from django.contrib.auth.models import User
from django.template import RequestContext
from  .models import UserData,Session,sessionLog
from django.contrib.auth import logout,login
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib import messages
import random
from django.http import JsonResponse
import time
from .models import session_members
# from django.shortcuts import render_to_response

#### 

def userType(ses_key,email):
    ses_list = list(Session.objects.values().filter(session_key=ses_key).filter(host_id=email))
    if ses_list.__len__()==1:
        return 'HOST'
    mem_list = list(session_members.objects.values().filter(session_key=ses_key).filter(user_id=email))
    if mem_list.__len__()==1:
        return 'MEMBER'
    return None

def checkCurrentSession(id):
    as_host = Session.objects.values().filter(host_id=id)
    expired_sessions = []
    for row in as_host:
        # checks for already expired or not
        if int(row['end_time']) < current_milli_time():
            return row['session_key']
        else:
            expired_sessions.append(row['session_key'])
    as_member = session_members.objects.values().filter(user_id
    =id)
    for row in as_member:
        if id == row['user'] and row['session_key'] not in expired_sessions:
            return row['session_key']


def current_milli_time():
    return round(time.time() * 1000)


# check for session_key exist or not9999
def isExistingSession(ses_key):
    user_list = session_members.objects.values().filter(session_key=ses_key).filter(permission='ACTIVE')
    ses_list = Session.objects.values().filter(session_key=ses_key).filter(end_time__gt=current_milli_time())  # end_time > current time
    if ses_list.__len__()>0:
            return True
    return False

def isUSerHavePermission(key,usr_id,user):
    print('in fun',key,usr_id,user)
    user_list = session_members.objects.values().filter(session_key=key).filter(user_id=usr_id)
    if user_list.__len__()>0:
        if user_list.filter(permission='ACTIVE'):
            return True
    else:
        data = session_members(session_key=key,user=getuser(usr_id),user_id=usr_id,permission='INACTIVE')
        data.save()
        return False
    return False
def getuser(id):
    data = list(UserData.objects.values().filter(user_mail=id))
    return data[0].get('user_name')

    

###


def aboutPage(request):
    return render(request,'about.html')


def firstPage(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'POST':
        print(isUSerHavePermission(request.POST.get('session_key'),request.user.email,request.user.username))
        if not isUSerHavePermission(request.POST.get('session_key'),request.user.email,request.user.username) or not isExistingSession(request.POST.get('session_key')):
            return JsonResponse({'msg' : 'false'})
        else:
            session_key =  request.POST.get('session_key')
            usr =  request.POST.get('user')
            mr =  request.POST.get('MR')
            ear =  request.POST.get('EAR')
            blinkRate =  request.POST.get('blinkRate')
            time_ms =current_milli_time()
            data = sessionLog(session_key=session_key,user=usr,mr=mr,ear=ear,blink_rate=blinkRate,time_ms=time_ms)
            data.save()
            return JsonResponse({
                'msg' : 'true'
            })

    if 'in_a_session' in request.COOKIES and request.user.is_authenticated:
        ses_key = key = str(request.COOKIES['session_key'])
        if request.COOKIES['user_type'] == 'MEMBER':            
            if isExistingSession(ses_key):
                if isUSerHavePermission(ses_key,request.user.email,request.user.username):
                    context = {'session_key' : ses_key,'user':getuser(request.user.username),'user_id':request.user.email}
                    res = render(request,'member-session.html',context)
                    res.set_cookie('user_type','MEMBER')
                    res.set_cookie('in_a_session','TRUE')
                    res.set_cookie('session_key',ses_key)
                    return res
                

        if request.COOKIES['user_type'] == 'HOST':
            return redirect('new/')        
    return redirect('/home')

# Create your views here.
def loginPage(request):
    if request.user.is_authenticated:
        return redirect('/session')
    else:
        if request.method == 'POST':
            email = request.POST.get('email')
            passw = request.POST.get('password')
            user = authenticate(request,username=email,password=passw)
            if user is not None:
                login(request,user)
                return redirect('/session/')
            else:
                messages.error(request, 'Something wrong,Try again!')
        context={}
        return render(request,'login.html',context)



def memberPage(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'POST':
        if not isUSerHavePermission(request.POST.get('session_key'),request.user.email,request.user.username):
            context={'err_msg':'Access denied by host,please wait'}
            return render(request,'session.html',context)
        session_key =  request.POST.get('session_key')
        usr =  request.POST.get('user')
        mr =  request.POST.get('MR')
        ear =  request.POST.get('EAR')
        blinkRate =  request.POST.get('blinkRate')
        time_ms =current_milli_time()
        data = sessionLog(session_key=session_key,user=usr,mr=mr,ear=ear,blink_rate=blinkRate,time_ms=time_ms)
        data.save()
        return JsonResponse({
            'msg' : 'true'
        })
    return render(request,'member-session.html',{'session_key' : '123456','user':'testuser'})



def userPage(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'access' : str(isUSerHavePermission(request.POST.get('session_key'),request.user.email,request.user.username))})
    context={}
    if request.method =='POST':
        context={}
        ses_key = request.POST.get('session_key')
        if isExistingSession(ses_key):
            if userType(ses_key,request.user.username) == 'HOST':
                print(ses_key,request.user.username)
                return newSession(request)
                # context = { 'session_key' : ses_key,
                # 'session_admin':request.user.username,
                # 'host_name':getuser(request.user.username)}
                # return render(request,'host-session.html',context)
            if isUSerHavePermission(ses_key,request.user.email,request.user.username):
                context = {'session_key' : ses_key,'user':request.user.username,'access':str(True)}
                res = render(request,'loading.html',context)
                res.set_cookie('user_type','MEMBER')
                res.set_cookie('in_a_session','TRUE')
                res.set_cookie('session_key',ses_key)
                return res
            else:
                context = {'session_key' : ses_key,'user':request.user.username,'access':str(False)}
                res = render(request,'loading.html',context)
                res.set_cookie('user_type','MEMBER')
                res.set_cookie('in_a_session','TRUE')
                res.set_cookie('session_key',ses_key)
                return res
        else:
            context={'err_msg':'Invalid session key or Session expired...!!'}
    return render(request,'session.html',context)

def home(request):
    # isExistingSession('279275')
    val = 'Sign In'
    link ='/login'
    col = '#6C63FF'
    if request.user.is_authenticated:
        val = 'Log Out'
        link='/logout'
        col = '#ff1111'
    con = {'userStatus' :val,'link':link,'color':col}
    return render(request,'home.html',context=con)

def indexPage(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest' and request.method == 'POST':
        if not isUSerHavePermission(request.POST.get('session_key'),request.user.email,request.user.username):
            context={'err_msg':'Access denied by host,please wait'}
            return render(request,'session.html',context)
        session_key =  request.POST.get('session_key')
        usr =  request.POST.get('user')
        mr =  request.POST.get('MR')
        ear =  request.POST.get('EAR')
        blinkrate =request.POST.get('blinkRate')
        time_ms =current_milli_time()
        data = sessionLog(session_key=session_key,user=usr,mr=mr,ear=ear,blink_rate=blinkrate,time_ms=time_ms)
        data.save()
        return JsonResponse({
            'msg' : 'true'
        })
    return render(request,'member-session.html',{'session_key' : '123456','user':'testuser'})


def RegisterPage(request):
    if request.user.is_authenticated:
        return redirect('/main/')
    else:
        if request.method == 'POST':
            uname = request.POST.get('uname')
            mail = request.POST.get('email')
            passw = request.POST.get('password')
            cpassw = request.POST.get('confirmpassword')
            age = request.POST.get('age')
            gender = request.POST.get('gender')
            try:
                user = User.objects.create_user(username=mail,email=mail,password=passw)
                if user is not None:
                    data = UserData(user_name=uname,user_mail=mail,gender=gender,age=age,password=passw)
                    data.save()
                    print('Data stored to DDB',data)
                    return redirect('/login/')
                else:
                    print('error')
            except:
                    messages.error(request, 'Can\'t create user,Check and try agian!')             
        return render(request,'register.html'  )

@login_required(login_url='/login/')
def mainPage(request):
    return render(request,'session-member.html')

def contactUs(request):
    return render(request,'contact_us.html')



@login_required(login_url='/login/')  
def profilePage(request):
    print(request.user.email)
    data = list(UserData.objects.values().filter(user_mail=request.user.email)) 
    print(data)#
    current_user=data[0].get('user_name')
    context = {'cur_usr':current_user,'cur_usr_email' : request.user.email}
    return render(request,'profile.html',context)

def logOutPage(request):
    logout(request)
    response =  redirect('/login')
    response.delete_cookie('session_key')
    response.delete_cookie('in_a_session')
    response.delete_cookie('user_type')
    return response



@login_required(login_url='/login/')
def curSession(request):
    return render(request,'member-session.html')



# new session creation
@login_required(login_url='/login/')
def newSession(request):
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        data = 'done'
        key = str(request.COOKIES['session_key'])
        if request.POST.get('type') == 'accept':
            u = session_members.objects.get(session_key=key,user_id=request.POST.get('user'))
            u.permission = 'ACTIVE'
            u.save()
        if request.POST.get('type') == 'deny':
            u = session_members.objects.get(session_key=key,user_id=request.POST.get('user'))
            u.permission = 'INACTIVE'
            u.save()
        if request.POST.get('type') == 'stats':
            c = { 'session_key' : key,
                'session_admin':request.user.username,
                'user':request.POST.get('user')}
            return render(request,'stats.html',c)
            
        if request.POST.get('type') == 'None':
            data = list(session_members.objects.values().filter(session_key=key))
        return JsonResponse({'data': data})
    
    session_key = random.randint(111111,999999)
    if 'in_a_session' in request.COOKIES:
        if request.COOKIES['in_a_session'] == 'TRUE':
            session_key = request.COOKIES['session_key']
    
    admin = request.user
    if not isExistingSession(session_key):
        exp_time = current_milli_time() + 3600*1000
        data = Session(session_key=session_key,host_id=request.user.email,host_name=getuser(admin.email),end_time=str(exp_time))
        data.save()
    context = { 'session_key' : session_key,
                'session_admin':admin.username,
                'host_name':getuser(admin.email)}
    response =  render(request,'host-session.html',context)
    if 'in_a_session' not in request.COOKIES:
        response.set_cookie('session_key',session_key,max_age=3600)
        response.set_cookie('in_a_session','TRUE',max_age=3600)
        response.set_cookie('user_type','HOST',max_age=3600)

    return response

def statsPage(request):
    if request.GET.get('user') == None:
        mailid= request.POST.get('userid')
    else:
        mailid= request.GET.get('user')
    if(mailid ==None):
        return redirect('/new/')
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        time = request.POST.get('time')
        print('time:',time)
        data = list(sessionLog.objects.values().filter(session_key=request.COOKIES['session_key']).filter(user=mailid).filter(time_ms__gt=time))#.filter(session_key=key))
        print("size ",data.__len__())
        return JsonResponse({'data': data})
        
    
    
    data = list(UserData.objects.values().filter(user_mail=mailid))
    print(data)
    # c={}
    c={'name' : data[0].get('user_name'),
       'mail': data[0].get('user_mail'),
        'gender':data[0].get('gender'),
        'age' :data[0].get('age') }
    return render(request,'stats.html',c)

    







## testingggggggggggggggggggg....


# def test(r):
#     return re
    # print(r.is_ajax())
    # if r.is_ajax():
    #     print(r.POST.get('name'))
    #     return JsonResponse({
    #         'msg' : 'true'
    #     })
    # # if r.method == 'POST':
    # #     print(r.POST.get('name'))
    # return render(r,'test-ajax.html')
